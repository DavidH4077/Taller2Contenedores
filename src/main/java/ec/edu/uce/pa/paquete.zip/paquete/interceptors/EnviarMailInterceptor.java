package ec.edu.uce.pa.paquete.interceptors;

public class EnviarMailInterceptor {

}
